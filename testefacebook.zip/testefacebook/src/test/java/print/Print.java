package print;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.Locale;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Print {
	
	public static String diretorio;
	
	public static void tiraPrint (String diretorio_nome_arq,WebDriver driver) throws IOException {

		
		
		GregorianCalendar calendar = new GregorianCalendar(); 
		Locale locale = new Locale("pt","BR");
		//SimpleDateFormat formatador = new SimpleDateFormat("dd'/'MM'/'yyyy'-'HH':'mm",locale); 
		//SimpleDateFormat formatador = new SimpleDateFormat("dd'_'MM'_'yyyy'_h'HH'_'mm",locale); se quiser informar as horas
		
		SimpleDateFormat formatador = new SimpleDateFormat("dd'_'MM'_'yyyy",locale);
		diretorio = diretorio_nome_arq + "_" + formatador.format(calendar.getTime()) + ".PNG";

		
		//Retira Evid�ncia
	    File scrnsht1 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrnsht1, new File(diretorio));
		
		
	}
}
