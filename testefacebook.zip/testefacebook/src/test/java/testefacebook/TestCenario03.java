package testefacebook;
import static org.junit.Assert.assertTrue;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.restfb.DefaultFacebookClient;
import com.restfb.FacebookClient;
import com.restfb.Parameter;
import com.restfb.types.GraphResponse;
import com.restfb.types.User;
import print.Print;

public class TestCenario03 {

	public WebDriver driver;
	public String url;
	public String url2;
	public String accesstoken = "TESTE123";
	public String password = "teste@123";

	@Before
	public void setUp() {

		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		url = "https://www.facebook.com/?stype=lo&jlou=AfedRm0aijSHnKC11kzzoBTkXkmGCWSPpXvuMxlDIvQgqol2jf_DSgPXRrvj-Typfs3M9ixxM3RvC6UJW4HtRdKF8rI-2pzO3pciwDmh89bh_A&smuh=14561&lh=Ac9NG03WRFnIk0Qi";
		url2 = "https://www.facebook.com/anderson.geraldo.3990";

	}
	
	@Test
	public void TestCena03() {
		driver.get(url);
		
		try {
		// autentica��o no facebook para pegar email
		FacebookClient pageclient = new DefaultFacebookClient(accesstoken);
		User me = pageclient.fetchObject("me", User.class, Parameter.with("fields", "name,email"));
				
		// postando publica��o no facebook
		GraphResponse publishMessageResponse = pageclient.publish("me/feed", GraphResponse.class, Parameter.with("message","Teste Automatizado no Facebook"));
			
		driver.findElement(By.id("email")).sendKeys(me.getEmail());
		driver.findElement(By.id("pass")).sendKeys(password);
		driver.findElement(By.id("pass")).submit();
		
		driver.get(url2);
		
		if (driver.getPageSource().contains("Teste Automatizado no Facebook")) {			
			
			assertTrue("Publish ja existente", false);
			
		} else {
			
			assertTrue("Publish NAO foi criado pelo acess token invalido", true);
		}
		
		//Rotina ira cair no catch devido o acess token ser invalido
		} catch (Exception teste) {
			
			assertTrue("Publish NAO foi criado pelo acess token invalido", true);
		}

			
	}

	@After
	public void tearDown() throws IOException {
		Print.tiraPrint("Evidencia/cenario_01", driver);
		driver.quit();
	}

}